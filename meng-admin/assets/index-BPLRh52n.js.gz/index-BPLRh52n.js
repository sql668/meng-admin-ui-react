import{j as r}from"./index-Rc6S57kw.js";import"./react-BDMrcVBD.js";import"./formily-g5To2R_f.js";import"./antd-A67M6I5q.js";const t=()=>r.jsx("div",{children:"menu 122"});export{t as default};
